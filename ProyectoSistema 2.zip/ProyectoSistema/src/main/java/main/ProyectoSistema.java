/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */
package main;

import ui.MainFrame;

/**
 * Clase main
 * 
 * @author Paulina, Alec, Sarah
 */
public class ProyectoSistema {

    public static void main(String[] args) {
        MainFrame mf = new MainFrame();
        mf.setVisible(true);
    }
}
